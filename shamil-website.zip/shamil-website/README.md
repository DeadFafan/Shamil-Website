# SHAMIL — Company Profile Website

Struktur folder:

```
shamil-website/
├── index.html          # Halaman utama
├── css/
│   └── style.css       # Semua styling + tema light/dark/auto
├── js/
│   └── main.js         # Slider hero, tema, menu, chat FAQ, back-to-top
├── assets/
│   └── img/
│       ├── logo.png        # Logo SHAMIL (background transparan)
│       ├── logo-mark.png   # Ikon globe saja (favicon)
│       └── logo.jpg        # Logo asli yang diunggah
└── README.md
```

## Cara menjalankan
Buka `index.html` langsung di browser, atau jalankan local server (opsional):
```
python3 -m http.server 8000
```
lalu buka `http://localhost:8000`.

## Fitur
- **Hero slider** 4 slide (Sea/Air/Land Freight, Customs & Project Cargo) dengan ilustrasi SVG bertema freight forwarding.
- **Tema Terang / Gelap / Otomatis** — tombol di navbar, tersimpan di localStorage. Mode "Otomatis" mengikuti preferensi sistem sekaligus jam malam (18.00–06.00 dianggap malam).
- **Chat widget** berbasis FAQ sederhana (tanpa perlu API/internet) di pojok kanan bawah.
- **Tombol kembali ke atas** muncul setelah scroll.
- Seluruhnya responsif dari mobile sampai desktop.

## Yang perlu Anda ganti
- Bagian **Mitra & Klien** (`#mitra` di `index.html`) masih berisi nama placeholder — ganti dengan mitra/klien asli beserta logonya.
- Data statistik, alamat, email, dan nomor telepon di bagian Kontak & Hero.
- Jika ingin chatbot AI (bukan FAQ statis), perlu backend/API terpisah karena file ini murni statis (HTML/CSS/JS).
